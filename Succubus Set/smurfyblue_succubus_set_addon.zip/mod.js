(() => {
    let mod = new Mod('SuccubusSetAddOn');
    mod.name = 'SuccubusSet Add-on';
    
    /* Queen - SuccuqueenQueen */
    mod.loadImage('Queen-Clothes-SuccuqueenQueen-NoPiercings', 'assets/Queen-Clothes-SuccuqueenQueen-NoPiercings.png');
    mod.loadImage('Queen-Clothes-SuccuqueenQueen-NoWig', 'assets/Queen-Clothes-SuccuqueenQueen-NoWig.png');
    mod.loadImage('Queen-Clothes-SuccuqueenQueen-NoPiercingsNoWig', 'assets/Queen-Clothes-SuccuqueenQueen-NoPiercingsNoWig.png');

    /* Suki - SukibusSuki */
    mod.loadImage('Suki-Clothes-SukibusSuki-NoPiercings', 'assets/Suki-Clothes-SukibusSuki-NoPiercings.png');

    /* Esxea - MiniSuccubusEsxea */
    mod.loadImage('Esxea-Clothes-MiniSuccubusEsxea-NoPiercings', 'assets/Esxea-Clothes-MiniSuccubusEsxea-NoPiercings.png');

    /* Scarlett - ScarlettbusScarlett */
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett-NoPiercings', 'assets/Scarlett-Clothes-ScarlettbusScarlett-NoPiercings.png');
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett-NoPiercingsNoTattoo', 'assets/Scarlett-Clothes-ScarlettbusScarlett-NoPiercingsNoTattoo.png');
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett-EarringOnly', 'assets/Scarlett-Clothes-ScarlettbusScarlett-EarringOnly.png');
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett-EarringOnlyNoTattoo', 'assets/Scarlett-Clothes-ScarlettbusScarlett-EarringOnlyNoTattoo.png');
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett-NoTattoo', 'assets/Scarlett-Clothes-ScarlettbusScarlett-NoTattoo.png');

    /* Ardura - SuccubusXLArdura */
    mod.loadImage('Ardura-Clothes-SuccubusXLArdura-NoPiercings', 'assets/Ardura-Clothes-SuccubusXLArdura-NoPiercings.png');
    mod.loadImage('Ardura-Clothes-SuccubusXLArdura-NoWig', 'assets/Ardura-Clothes-SuccubusXLArdura-NoWig.png');
    mod.loadImage('Ardura-Clothes-SuccubusXLArdura-NoPiercingsNoWig', 'assets/Ardura-Clothes-SuccubusXLArdura-NoPiercingsNoWig.png');

    /* Natasha - HolySuccubusNatasha */
    mod.loadImage('Natasha-Clothes-HolySuccubusNatasha-NoPiercings', 'assets/Natasha-Clothes-HolySuccubusNatasha-NoPiercings.png');

    mod.boot = () => {
        if (MODS.SuccubusSet) {
            let NoPiercingsStyle = new ClothesStyle('NoPiercings', 'No Piercings', true);
            let NoWigStyle = new ClothesStyle('NoWig', 'No Wig', true);
            let NoPiercingsNoWigStyle = new ClothesStyle('NoPiercingsNoWig', 'No Piercings/Wig', true);
            
            /* Queen - SuccuqueenQueen */
            mod.clothes.Clothes.SuccuqueenQueen.addStyle(NoPiercingsStyle);
            mod.clothes.Clothes.SuccuqueenQueen.addStyle(NoWigStyle);
            mod.clothes.Clothes.SuccuqueenQueen.addStyle(NoPiercingsNoWigStyle);

            /* Suki - SukibusSuki */
            mod.clothes.Clothes.SukibusSuki.addStyle(NoPiercingsStyle);

            /* Esxea - MiniSuccubusEsxea */
            mod.clothes.Clothes.MiniSuccubusEsxea.addStyle(NoPiercingsStyle);

            /* Scarlett - ScarlettbusScarlett */
            mod.clothes.Clothes.ScarlettbusScarlett.addStyle(new ClothesStyle('NoTattoo', 'No Tattoo', true));
            mod.clothes.Clothes.ScarlettbusScarlett.addStyle(NoPiercingsStyle);
            mod.clothes.Clothes.ScarlettbusScarlett.addStyle(new ClothesStyle('NoPiercingsNoTattoo', 'No Piercings/Tattoo', true));
            mod.clothes.Clothes.ScarlettbusScarlett.addStyle(new ClothesStyle('EarringOnly', 'Earring Only', true));
            mod.clothes.Clothes.ScarlettbusScarlett.addStyle(new ClothesStyle('EarringOnlyNoTattoo', 'Earring Only, No Tattoo', true));
            
            /* Ardura - SuccubusXLArdura */
            mod.clothes.Clothes.SuccubusXLArdura.addStyle(NoPiercingsStyle);
            mod.clothes.Clothes.SuccubusXLArdura.addStyle(NoWigStyle);
            mod.clothes.Clothes.SuccubusXLArdura.addStyle(NoPiercingsNoWigStyle);
            
            /* Natasha - HolySuccubusNatasha */
            mod.clothes.Clothes.HolySuccubusNatasha.addStyle(NoPiercingsStyle);
        }
    }
})();