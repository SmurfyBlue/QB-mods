(() =>{let mod = new Mod('SuccubusSet');
mod.name = 'SuccubusSet';
mod.loadImage('SuccuqueenQueen', 'assets/SuccuqueenQueen.png');
mod.loadImage('Queen-Clothes-SuccuqueenQueen', 'assets/Queen-Clothes-SuccuqueenQueen.png');
mod.loadImage('SukibusSuki', 'assets/SukibusSuki.png');
mod.loadImage('Suki-Clothes-SukibusSuki', 'assets/Suki-Clothes-SukibusSuki.png');
mod.loadImage('MiniSuccubusEsxea', 'assets/MiniSuccubusEsxea.png');
mod.loadImage('Esxea-Clothes-MiniSuccubusEsxea', 'assets/Esxea-Clothes-MiniSuccubusEsxea.png');
mod.loadImage('ScarlettbusScarlett', 'assets/ScarlettbusScarlett.png');
mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett', 'assets/Scarlett-Clothes-ScarlettbusScarlett.png');
mod.loadImage('SuccubusXLArdura', 'assets/SuccubusXLArdura.png');
mod.loadImage('Ardura-Clothes-SuccubusXLArdura', 'assets/Ardura-Clothes-SuccubusXLArdura.png');
mod.loadImage('HolySuccubusNatasha', 'assets/HolySuccubusNatasha.png');
mod.loadImage('Natasha-Clothes-HolySuccubusNatasha', 'assets/Natasha-Clothes-HolySuccubusNatasha.png');


mod.init = () => {
mod.clothes.add(new Clothes('SuccuqueenQueen', 'Queen', false)).setName('Succuqueen').setDescription('Will literally drain you dry of cum and money.').setLevel(15).setStat({"Throat":6,"Tits":2,"Pussy":3,"Anal":1}).setCost(666).setShop(true).setVisible(true);
mod.clothes.add(new Clothes('SukibusSuki', 'Suki', false)).setName('Sukibus').setDescription('There was always a little devil in her.').setLevel(15).setStat({"Throat":1,"Tits":2,"Pussy":6,"Anal":1}).setCost(666).setShop(true).setVisible(true);
mod.clothes.add(new Clothes('MiniSuccubusEsxea', 'Esxea', false)).setName('Mini Succubus').setDescription('Smaller than your average demon!').setLevel(15).setStat({"Throat":2,"Tits":6,"Pussy":0,"Anal":1}).setCost(666).setShop(true).setVisible(true);
mod.clothes.add(new Clothes('ScarlettbusScarlett', 'Scarlett', false)).setName('Scarlettbus').setDescription('Is this outfit even legal?').setLevel(15).setStat({"Throat":1,"Tits":6,"Pussy":2,"Anal":1}).setCost(666).setShop(true).setVisible(true);
mod.clothes.add(new Clothes('SuccubusXLArdura', 'Ardura', false)).setName('Succubus XL').setDescription('Your Dad calls her Mommy too').setLevel(15).setStat({"Throat":0,"Tits":2,"Pussy":2,"Anal":6}).setCost(666).setShop(true).setVisible(true);
mod.clothes.add(new Clothes('HolySuccubusNatasha', 'Natasha', false)).setName('Holy Succubus').setDescription('Church going has never been so fun.').setLevel(15).setStat({"Throat":0,"Tits":2,"Pussy":6,"Anal":0}).setCost(666).setShop(true).setVisible(true);

};})();