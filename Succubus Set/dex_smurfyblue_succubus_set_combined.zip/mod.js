(() => {
    let mod = new Mod('SuccubusSetCombi');
    mod.name = 'Succubus Set Combined';
    
    /* Queen - SuccuqueenQueen - Original */
    mod.loadImage('SuccuqueenQueen', 'assets/SuccuqueenQueen.png');
    mod.loadImage('Queen-Clothes-SuccuqueenQueen', 'assets/Queen-Clothes-SuccuqueenQueen.png');
    /* Queen - SuccuqueenQueen - Styles */
    mod.loadImage('Queen-Clothes-SuccuqueenQueen-NoPiercings', 'assets/Queen-Clothes-SuccuqueenQueen-NoPiercings.png');
    mod.loadImage('Queen-Clothes-SuccuqueenQueen-NoWig', 'assets/Queen-Clothes-SuccuqueenQueen-NoWig.png');
    mod.loadImage('Queen-Clothes-SuccuqueenQueen-NoPiercingsNoWig', 'assets/Queen-Clothes-SuccuqueenQueen-NoPiercingsNoWig.png');

    /* Suki - SukibusSuki - Original */
    mod.loadImage('SukibusSuki', 'assets/SukibusSuki.png');
    mod.loadImage('Suki-Clothes-SukibusSuki', 'assets/Suki-Clothes-SukibusSuki.png');
    /* Suki - SukibusSuki - Styles */
    mod.loadImage('Suki-Clothes-SukibusSuki-NoPiercings', 'assets/Suki-Clothes-SukibusSuki-NoPiercings.png');

    /* Esxea - MiniSuccubusEsxea - Original */
    mod.loadImage('MiniSuccubusEsxea', 'assets/MiniSuccubusEsxea.png');
    mod.loadImage('Esxea-Clothes-MiniSuccubusEsxea', 'assets/Esxea-Clothes-MiniSuccubusEsxea.png');
    /* Esxea - MiniSuccubusEsxea - Styles */
    mod.loadImage('Esxea-Clothes-MiniSuccubusEsxea-NoPiercings', 'assets/Esxea-Clothes-MiniSuccubusEsxea-NoPiercings.png');

    /* Scarlett - ScarlettbusScarlett - Original */
    mod.loadImage('ScarlettbusScarlett', 'assets/ScarlettbusScarlett.png');
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett', 'assets/Scarlett-Clothes-ScarlettbusScarlett.png');
    /* Scarlett - ScarlettbusScarlett - Styles */
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett-NoPiercings', 'assets/Scarlett-Clothes-ScarlettbusScarlett-NoPiercings.png');
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett-NoPiercingsNoTattoo', 'assets/Scarlett-Clothes-ScarlettbusScarlett-NoPiercingsNoTattoo.png');
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett-EarringOnly', 'assets/Scarlett-Clothes-ScarlettbusScarlett-EarringOnly.png');
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett-EarringOnlyNoTattoo', 'assets/Scarlett-Clothes-ScarlettbusScarlett-EarringOnlyNoTattoo.png');
    mod.loadImage('Scarlett-Clothes-ScarlettbusScarlett-NoTattoo', 'assets/Scarlett-Clothes-ScarlettbusScarlett-NoTattoo.png');

    /* Ardura - SuccubusXLArdura - Original */
    mod.loadImage('SuccubusXLArdura', 'assets/SuccubusXLArdura.png');
    mod.loadImage('Ardura-Clothes-SuccubusXLArdura', 'assets/Ardura-Clothes-SuccubusXLArdura.png');
    /* Ardura - SuccubusXLArdura - Styles */
    mod.loadImage('Ardura-Clothes-SuccubusXLArdura-NoPiercings', 'assets/Ardura-Clothes-SuccubusXLArdura-NoPiercings.png');
    mod.loadImage('Ardura-Clothes-SuccubusXLArdura-NoWig', 'assets/Ardura-Clothes-SuccubusXLArdura-NoWig.png');
    mod.loadImage('Ardura-Clothes-SuccubusXLArdura-NoPiercingsNoWig', 'assets/Ardura-Clothes-SuccubusXLArdura-NoPiercingsNoWig.png');

    /* Natasha - HolySuccubusNatasha - Original */
    mod.loadImage('HolySuccubusNatasha', 'assets/HolySuccubusNatasha.png');
    mod.loadImage('Natasha-Clothes-HolySuccubusNatasha', 'assets/Natasha-Clothes-HolySuccubusNatasha.png');
    /* Natasha - HolySuccubusNatasha - Styles */
    mod.loadImage('Natasha-Clothes-HolySuccubusNatasha-NoPiercings', 'assets/Natasha-Clothes-HolySuccubusNatasha-NoPiercings.png');

    mod.init = () => {
        let NoPiercingsStyle = new ClothesStyle('NoPiercings', 'No Piercings', true);
        let NoWigStyle = new ClothesStyle('NoWig', 'No Wig', true);
        let NoPiercingsNoWigStyle = new ClothesStyle('NoPiercingsNoWig', 'No Piercings/Wig', true);
        
        /* Queen - SuccuqueenQueen */
        mod.clothes.add(new Clothes('SuccuqueenQueen', 'Queen', false))
            .setName('Succuqueen')
            .setDescription('Will literally drain you dry of cum and money.')
            .setLevel(15)
            .setStat({"Throat":6,"Tits":2,"Pussy":3,"Anal":1})
            .setCost(666)
            .setShop(true)
            .setVisible(true)
        ;
        mod.clothes.Clothes.SuccuqueenQueen.addStyle(NoPiercingsStyle);
        mod.clothes.Clothes.SuccuqueenQueen.addStyle(NoWigStyle);
        mod.clothes.Clothes.SuccuqueenQueen.addStyle(NoPiercingsNoWigStyle);

        /* Suki - SukibusSuki */
        mod.clothes.add(new Clothes('SukibusSuki', 'Suki', false))
            .setName('Sukibus')
            .setDescription('There was always a little devil in her.')
            .setLevel(15)
            .setStat({"Throat":1,"Tits":2,"Pussy":6,"Anal":1})
            .setCost(666)
            .setShop(true)
            .setVisible(true)
        ;
        mod.clothes.Clothes.SukibusSuki.addStyle(NoPiercingsStyle);

        /* Esxea - MiniSuccubusEsxea */
        mod.clothes.add(new Clothes('MiniSuccubusEsxea', 'Esxea', false))
            .setName('Mini Succubus')
            .setDescription('Smaller than your average demon!')
            .setLevel(15)
            .setStat({"Throat":2,"Tits":6,"Pussy":0,"Anal":1})
            .setCost(666)
            .setShop(true)
            .setVisible(true)
        ;
        mod.clothes.Clothes.MiniSuccubusEsxea.addStyle(NoPiercingsStyle);

        /* Scarlett - ScarlettbusScarlett */
        mod.clothes.add(new Clothes('ScarlettbusScarlett', 'Scarlett', false))
            .setName('Scarlettbus')
            .setDescription('Is this outfit even legal?')
            .setLevel(15)
            .setStat({"Throat":1,"Tits":6,"Pussy":2,"Anal":1})
            .setCost(666)
            .setShop(true)
            .setVisible(true)
        ;
        mod.clothes.Clothes.ScarlettbusScarlett.addStyle(new ClothesStyle('NoTattoo', 'No Tattoo', true));
        mod.clothes.Clothes.ScarlettbusScarlett.addStyle(NoPiercingsStyle);
        mod.clothes.Clothes.ScarlettbusScarlett.addStyle(new ClothesStyle('NoPiercingsNoTattoo', 'No Piercings/Tattoo', true));
        mod.clothes.Clothes.ScarlettbusScarlett.addStyle(new ClothesStyle('EarringOnly', 'Earring Only', true));
        mod.clothes.Clothes.ScarlettbusScarlett.addStyle(new ClothesStyle('EarringOnlyNoTattoo', 'Earring Only, No Tattoo', true));
        
        /* Ardura - SuccubusXLArdura */
        mod.clothes.add(new Clothes('SuccubusXLArdura', 'Ardura', false))
            .setName('Succubus XL')
            .setDescription('Your Dad calls her Mommy too')
            .setLevel(15)
            .setStat({"Throat":0,"Tits":2,"Pussy":2,"Anal":6})
            .setCost(666)
            .setShop(true)
            .setVisible(true)
        ;
        mod.clothes.Clothes.SuccubusXLArdura.addStyle(NoPiercingsStyle);
        mod.clothes.Clothes.SuccubusXLArdura.addStyle(NoWigStyle);
        mod.clothes.Clothes.SuccubusXLArdura.addStyle(NoPiercingsNoWigStyle);
        
        /* Natasha - HolySuccubusNatasha */
        mod.clothes.add(new Clothes('HolySuccubusNatasha', 'Natasha', false))
            .setName('Holy Succubus')
            .setDescription('Church going has never been so fun.')
            .setLevel(15)
            .setStat({"Throat":0,"Tits":2,"Pussy":6,"Anal":0})
            .setCost(666)
            .setShop(true)
            .setVisible(true)
        ;
        mod.clothes.Clothes.HolySuccubusNatasha.addStyle(NoPiercingsStyle);
    }
})();