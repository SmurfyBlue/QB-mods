(() => {
    let mod = new Mod('DefaultStyleExtender');
    mod.name = 'Default Style Extender';

    /* Bodies */
        /* Suki */
            mod.loadImage('Suki-Body-Default', 'assets/Bodies/Suki/Suki-Body-NoPiercings.png');
    
    /* Clothes */
        /* Queen */
            /* DefaultQueen */
                mod.loadImage('Queen-Clothes-DefaultQueen-Green', 'assets/Clothing/Queen/Queen-Clothes-DefaultQueen-Green.png');
                mod.loadImage('Queen-Clothes-DefaultQueen-Black', 'assets/Clothing/Queen/Queen-Clothes-DefaultQueen-Black.png');
                mod.loadImage('Queen-Clothes-DefaultQueen-AlphaRed', 'assets/Clothing/Queen/Queen-Clothes-DefaultQueen-AlphaRed.png');
                mod.loadImage('Queen-Clothes-DefaultQueen-AlphaGreen', 'assets/Clothing/Queen/Queen-Clothes-DefaultQueen-AlphaGreen.png');
                
            /* SchoolgirlQueen */
                mod.loadImage('Queen-Clothes-SchoolgirlQueen-Open', 'assets/Clothing/Queen/Queen-Clothes-SchoolgirlQueen-Open.png');
                mod.loadImage('Queen-Clothes-SchoolgirlQueen-OpenShortSkirt', 'assets/Clothing/Queen/Queen-Clothes-SchoolgirlQueen-OpenShortSkirt.png');
            /* ForestQueen */
                mod.loadImage('Queen-Clothes-ForestQueen-Leaf', 'assets/Clothing/Queen/Queen-Clothes-ForestQueen-Leaf.png');
                mod.loadImage('Queen-Clothes-ForestQueen-LeafFall', 'assets/Clothing/Queen/Queen-Clothes-ForestQueen-LeafFall.png');
        /* Suki */
            /* DefaultSuki */
                mod.loadImage('Suki-Clothes-DefaultSuki-Open', 'assets/Clothing/Suki/Suki-Clothes-DefaultSuki-Open.png');
                mod.loadImage('Suki-Clothes-DefaultSuki-OpenShortSkirt', 'assets/Clothing/Suki/Suki-Clothes-DefaultSuki-OpenShortSkirt.png');
            /* ForestSuki */
                mod.loadImage('Suki-Clothes-ForestSuki-Leaf', 'assets/Clothing/Suki/Suki-Clothes-ForestSuki-Leaf.png');
                mod.loadImage('Suki-Clothes-ForestSuki-LeafFall', 'assets/Clothing/Suki/Suki-Clothes-ForestSuki-LeafFall.png');
            /* LeotardSuki */
                mod.loadImage('Suki-Clothes-LeotardSuki-SeeThrough', 'assets/Clothing/Suki/Suki-Clothes-LeotardSuki-SeeThrough.png');
        /* Ardura */
            /* DefaultArdura */
                mod.loadImage('Ardura-Clothes-DefaultArdura-LessArmor', 'assets/Clothing/Ardura/Ardura-Clothes-DefaultArdura-LessArmor.png');
                mod.loadImage('Ardura-Clothes-DefaultArdura-NoShield', 'assets/Clothing/Ardura/Ardura-Clothes-DefaultArdura-NoShield.png');
            /* ForestArdura */
                mod.loadImage('Ardura-Clothes-ForestArdura-Leaf', 'assets/Clothing/Ardura/Ardura-Clothes-ForestArdura-Leaf.png');
                mod.loadImage('Ardura-Clothes-ForestArdura-LeafFall', 'assets/Clothing/Ardura/Ardura-Clothes-ForestArdura-LeafFall.png');
        /* Esxea */
            /* DefaultEsxea */
                mod.loadImage('Esxea-Clothes-DefaultEsxea-Clothes', 'assets/Clothing/Esxea/Esxea-Clothes-DefaultEsxea-Clothes.png');
                mod.loadImage('Esxea-Clothes-DefaultEsxea-TubeTop', 'assets/Clothing/Esxea/Esxea-Clothes-DefaultEsxea-TubeTop.png');

    mod.init = () => {
        /* Queen */
            /* DefaultQueen */
                mod.clothes.Clothes.DefaultQueen.addStyle(new ClothesStyle('AlphaRed', 'Transparent Red', () => {
                    return mod.quest.isComplete('alphaBlack', 'Start');
                }));
                mod.clothes.Clothes.DefaultQueen.addStyle(new ClothesStyle('AlphaGreen', 'Transparent Green', () => {
                    return mod.quest.isComplete('alphaBlack', 'Start');
                }));
                mod.clothes.Clothes.DefaultQueen.addStyle(new ClothesStyle('Green', 'Green', true));
                mod.clothes.Clothes.DefaultQueen.addStyle(new ClothesStyle('Black', 'Black', true));

            /* SchoolgirlQueen */
                mod.clothes.Clothes.SchoolgirlQueen.addStyle(new ClothesStyle('Open', 'Open Cleavage', true));
                mod.clothes.Clothes.SchoolgirlQueen.addStyle(new ClothesStyle('OpenShortSkirt', 'Open Cleavage w/ Shorter Skirt', true));

            /* ForestQueen */
                mod.clothes.Clothes.ForestQueen.addStyle(new ClothesStyle('Leaf', 'Leaf', true));
                mod.clothes.Clothes.ForestQueen.addStyle(new ClothesStyle('LeafFall', 'Dead Leaf', true));

        /* Suki */
            /* DefaultSuki */
                mod.clothes.Clothes.DefaultSuki.addStyle(new ClothesStyle('Open', 'Open Cleavage', true));
                mod.clothes.Clothes.DefaultSuki.addStyle(new ClothesStyle('OpenShortSkirt', 'Open Cleavage w/ Shorter Skirt', true));
        
            /* ForestSuki */
                mod.clothes.Clothes.ForestSuki.addStyle(new ClothesStyle('Leaf', 'Leaf', true));
                mod.clothes.Clothes.ForestSuki.addStyle(new ClothesStyle('LeafFall', 'Dead Leaf', true));

            /* LeotardSuki */
                mod.clothes.Clothes.LeotardSuki.addStyle(new ClothesStyle('SeeThrough', 'Transparent', true));
        
        /* Ardura */
            /* DefaultArdura */
                mod.clothes.Clothes.DefaultArdura.addStyle(new ClothesStyle('LessArmor', 'Stripped Armor', true));
                mod.clothes.Clothes.DefaultArdura.addStyle(new ClothesStyle('NoShield', 'No Shield', true));
            /* ForestArdura */
                mod.clothes.Clothes.ForestArdura.addStyle(new ClothesStyle('Leaf', 'Leaf', true));
                mod.clothes.Clothes.ForestArdura.addStyle(new ClothesStyle('LeafFall', 'Dead Leaf', true));

        /* Esxea */
            /* DefaultEsxea */
                mod.clothes.Clothes.DefaultEsxea.addStyle(new ClothesStyle('Clothes', 'Actual Clothes', true));
                mod.clothes.Clothes.DefaultEsxea.addStyle(new ClothesStyle('TubeTop', 'Ripped Tube Top', true));

        /* ------------------------------------ */
        
        // Sort styles alphabetically
        for (clothing in mod.clothes.Clothes) {
            if (Object.keys(mod.clothes.Clothes[clothing].styles).length > 1) {
                let oldStyles = mod.clothes.Clothes[clothing].styles;
                delete oldStyles.false;
                let newStyles = {};

                oldStyles = Object.keys(oldStyles).sort().reduce((Obj, key) => {
                    Obj[key] = oldStyles[key];
                    return Obj;
                }, {});

                // Extra code for DefaultQueen with transparent versions
                if(clothing == "DefaultQueen") {
                    let newAlpha = {};
                    let newNormal = {};

                    newAlpha['AlphaRed'] = oldStyles['AlphaRed'];
                    delete oldStyles['AlphaRed'];

                    for (old in oldStyles) {
                        if (old.includes("Alpha")) {
                            newAlpha[old] = oldStyles[old];
                        }
                        else {
                            newNormal[old] = oldStyles[old];
                        }
                    }
                    
                    newStyles = { false: new ClothesStyle(false, "Default", true) };
                    newStyles = Object.assign(newStyles, newNormal, newAlpha);
                }
                // Otherwise, just make sure Default is first
                else {
                    newStyles = Object.assign( { false: new ClothesStyle(false, "Default", true) }, oldStyles );
                }

                mod.clothes.Clothes[clothing].styles = newStyles;
            }
        }

        // Add other Alpha recolours to be elligable for the alphaBlack quest
        mod.quest.getQuest('alphaBlack', 'End').setProgress(() => {
            return mod.girl.Queen.getClothes().getID() === "DefaultQueen" && ["AlphaBlack", "AlphaRed", "AlphaGreen"].includes(mod.girl.Queen.getClothes().getPlayerStyle());
        });
    };

    mod.boot = () => {
        mod.notify('Thanks for using the Default Style Extender mod!');
        mod.notify('Have fun!');
    }
})();