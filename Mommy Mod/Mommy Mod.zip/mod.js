(() => {
    let mod = new Mod('MommyMod');
    mod.name = 'Mommy Mod';
    
    mod.init = () => {
        for (_girl in mod.girl._girls) {
            let sb_girl = mod.girl[mod.girl._girls[_girl]];
            sb_girl.age += 10;
            if (sb_girl.getAge() < 30) {
                sb_girl.age = 30;
            }
        }
    };

    mod.boot = () => {
        mod.notify("I can't believe you actually installed this...");
    }
})();