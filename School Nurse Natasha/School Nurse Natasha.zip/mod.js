(() => {
    let mod = new Mod('SchoolNurse');
    mod.name = 'School Nurse';

    //Outfit
    mod.loadImage('NurseSkirtNatasha', 'assets/NurseSkirtNatasha.png');
    mod.loadImage('Natasha-Clothes-NurseSkirtNatasha', 'assets/Natasha-Clothes-NurseSkirtNatasha.png');

    mod.init = () => {
        //Outfit
        mod.clothes.add(new Clothes('NurseSkirtNatasha', 'Natasha', false))
            .setName('Nurse Skirt')
            .setDescription('nurse')
            .setLevel(15)
            .setStat({
                "Throat": 2,
                "Tits": 0,
                "Pussy": 2,
                "Anal": 0
            })
            .setCost(500)
            .setShop(true)
            .setVisible(true)
        ;

        //Quest
        mod.quest.addQuest('AWOLNurse', 'AWOLNurse', false);
        mod.dialogue.addDialogueTree('AWOLNurse');
        mod.quest.getQuest('AWOLNurse').addSubQuest('Exploretheschool');
        mod.dialogue.getDialogueTree('AWOLNurse').addBranch('Exploretheschool');
        mod.quest.getQuest('AWOLNurse').getSubQuests('Exploretheschool').setProgress(true);
        mod.quest.getQuest('AWOLNurse').getSubQuests('Exploretheschool').setMapKey('PrincipalsOfficeButton');
        mod.quest.getQuest('AWOLNurse').getSubQuests('Exploretheschool').setDialogueTree('AWOLNurse');
        mod.quest.getQuest('AWOLNurse').getSubQuests('Exploretheschool').setDialogueBranch('Exploretheschool');
        mod.quest.getQuest('AWOLNurse').getSubQuests('Exploretheschool').setCondition(true);
        mod.quest.getQuest('AWOLNurse').setStart('Exploretheschool');
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Suki', "So why did you want to come with me again? It’s just a school, I did everything I could to get out of this place.", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Natasha', "I’ve never been to a school with girls AND boys. It’s amazing! They’re not separated at all you could reach out and just …", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Suki', "Uh yeah ok sure. So I have to go talk to this old perv of a principal who keeps making me come back here. You just stay out here and don’t get into too much trouble.", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Natasha', "Oh I won’t. I’m just going to look around at all the cute bo….um books yeah books. ", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('', "They hear a commotion coming down the hall. It’s a student in what is obviously a beat ball uniform. He runs right in front of them and starts pounding on the principal’s door. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Principal', "What?!?!", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Daniel', "It’s Kevin! He’s hurt on the field. I think he broke something! ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Principal', "Oh great. Our nurse runs off to go volunteer in the Westhaven slums and someone gets hurt. What are you two doing here?", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Suki', "You told me to come!", "Surprise");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Principal', "Well unless you can do something about a broken bone I don’t have time for you. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Suki', "I can break your ..", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Natasha', "I can help! ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Principal', "You can? Oh you’re an elf, do you know magic? ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').talk('Natasha', "Of course! I think I can help. Take me to him. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Exploretheschool').completeQuest('AWOLNurse', 'Exploretheschool');
        mod.quest.getQuest('AWOLNurse').addSubQuest('Anewjob');
        mod.dialogue.getDialogueTree('AWOLNurse').addBranch('Anewjob');
        mod.quest.getQuest('AWOLNurse').getSubQuests('Anewjob').setProgress(true);
        mod.quest.getQuest('AWOLNurse').getSubQuests('Anewjob').setMapKey('PrincipalsOfficeButton');
        mod.quest.getQuest('AWOLNurse').getSubQuests('Anewjob').setDialogueTree('AWOLNurse');
        mod.quest.getQuest('AWOLNurse').getSubQuests('Anewjob').setDialogueBranch('Anewjob');
        mod.quest.getQuest('AWOLNurse').getSubQuests('Anewjob').setCondition(() => {
            return mod.quest.isComplete('AWOLNurse', 'Exploretheschool');
        });
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Anewjob').talk('Principal', "That was amazing! You just pointed at him and that glowy stuff and BAM! He was fine. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Anewjob').talk('Principal', "Say could you be our nurse until the other one gets back? ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Anewjob').talk('Suki', "You know she has a job right? ", "Angry");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Anewjob').talk('Principal', "I’ll pay! Besides she can do this during the day and the other at night if she wants. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Anewjob').talk('Natasha', "So you want me to come here and spend all day around all these cute bo...books? I’ll do it! ", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Anewjob').talk('Principal', "Great! Just get a nurse uniform. Come back when you get it. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Anewjob').talk('Natasha', "What’s a nurse uniform? ", "Surprise");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Anewjob').talk('Principal', "Just ask Cassie, she’ll know what to give you. Suki! In my office!", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Anewjob').talk('Suki', "ULP!", "Surprise");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('Anewjob').completeQuest('AWOLNurse', 'Anewjob');
        mod.quest.getQuest('AWOLNurse').addSubQuest('NewUniform');
        mod.dialogue.getDialogueTree('AWOLNurse').addBranch('NewUniform');
        mod.quest.getQuest('AWOLNurse').getSubQuests('NewUniform').setProgress(true);
        mod.quest.getQuest('AWOLNurse').getSubQuests('NewUniform').setMapKey('TownClothesShop');
        mod.quest.getQuest('AWOLNurse').getSubQuests('NewUniform').setDialogueTree('AWOLNurse');
        mod.quest.getQuest('AWOLNurse').getSubQuests('NewUniform').setDialogueBranch('NewUniform');
        mod.quest.getQuest('AWOLNurse').getSubQuests('NewUniform').setCondition(() => {
            return mod.quest.isComplete('AWOLNurse', 'Anewjob');
        });
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('NewUniform').talk('Cassie', "Hi Natasha! What do you need?", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('NewUniform').talk('Natasha', "I need a nurse uniform. Do you have those? ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('NewUniform').talk('Cassie', "You’re in luck I have one left! The guys are going to love you in this one. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('NewUniform').talk('Natasha', "Wow, I didn’t know this is what they looked like. I should have gone to the school way sooner. Bye!", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('NewUniform').talk('Cassie', "Wait a real one? Uh oh.", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('NewUniform').completeQuest('AWOLNurse', 'NewUniform');
        mod.quest.getQuest('AWOLNurse').addSubQuest('FirstDay');
        mod.dialogue.getDialogueTree('AWOLNurse').addBranch('FirstDay');
        mod.quest.getQuest('AWOLNurse').getSubQuests('FirstDay').setProgress(true);
        mod.quest.getQuest('AWOLNurse').getSubQuests('FirstDay').setMapKey('PrincipalsOfficeButton');
        mod.quest.getQuest('AWOLNurse').getSubQuests('FirstDay').setDialogueTree('AWOLNurse');
        mod.quest.getQuest('AWOLNurse').getSubQuests('FirstDay').setDialogueBranch('FirstDay');
        mod.quest.getQuest('AWOLNurse').getSubQuests('FirstDay').setCondition(() => {
            return mod.quest.isComplete('AWOLNurse', 'NewUniform');
        });
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', "I’m back! What should I do?", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Principal', "Um … your uniform… it’s um. Well whatever. The nurses office across the hall from my office, but for now just go out to the beatball field in case they have a problem.", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('', "Natasha sits in the stands and tries to follow the action. There is lots of running and more than a few accidents; mostly due to the players staring at her instead of the ball. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('', "She treats two concussions, five sprains, and a broken ankle before practice ends. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Thomas', "Hey you nurse! ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', "Yes sir? ", "Surprise");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Thomas', "Thanks for all the help today, but now we have another problem. Your outfit is too distracting. My players can’t focus and with Suki gone I don’t know what to do. Can you help them?", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', "Help them? ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Thomas', "Yeah you know. The way you would help them if they were at your other job? I’ll pay, but not much. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', "Not much?", "Angry");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Thomas', "You don’t have to go crazy. Just drain them real good. You know what they say, “Empty balls clear head!”", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', "I don’t think they actually say that, but I have an idea that will work. Just have my money ready. ", "Angry");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('', "She walks into the locker room. The players are all almost completely stripped down and about to head for the showers. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', "Ok guys. Your coach says you need better focus on the field. Everybody drop those shorts and sit on the bench. ", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('', "They look at each other and shrug. More than a few of them are starting to come to attention. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', "Everyone relax and lean back a little bit. Good! ", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('', "She walks over to the bench and kneels between the legs of the player on the end. Without wasting time she takes him in her mouth and in moments he’s rock hard. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('', "As he builds towards cuming she pulls out a small vial from somewhere and dips a finger in it.  His excitement is building but she senses him relax.", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('', "Without warning she slips that finger right up his ass, the player’s eyes get huge but it’s too late, her finger finds its mark and with zero control over his body he starts to erupt in her mouth. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('', "After the last spurt he slumps to the side.", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Thomas', " I have never cum so hard in my life.", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('', "The other players who were about to nope out think better of it and decide to wait their turn. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('', "After she makes her way down the bench and draining every ball in the room Natasha walks over to the coach. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', "Whew ok well they were WAY more backed up than I thought. I’m going to be tasting that spunk all night!", "Surprise");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').cumOn('Natasha', 'Throat', 4);
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Thomas', "That was amazing. They’re so drained they can barely stand up in the shower. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', "Yup I’m a pro! Now about that gold!", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Thomas', "Here you earned it. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Thomas', "Say we have an alumni break ball game coming up soon. Those guys always hurt themselves. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', " I dunno I have a real job you know. ", "Sad");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Thomas', "These guys will pay for sure. Especially if you wear your um… uniform. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').talk('Natasha', "Why not, I might as well get some use out of this thing anyway. ", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('FirstDay').completeQuest('AWOLNurse', 'FirstDay');
        mod.quest.getQuest('AWOLNurse').addSubQuest('AlumniGame');
        mod.dialogue.getDialogueTree('AWOLNurse').addBranch('AlumniGame');
        mod.quest.getQuest('AWOLNurse').getSubQuests('AlumniGame').setProgress(true);
        mod.quest.getQuest('AWOLNurse').getSubQuests('AlumniGame').setMapKey('CafeteriaButton');
        mod.quest.getQuest('AWOLNurse').getSubQuests('AlumniGame').setDialogueTree('AWOLNurse');
        mod.quest.getQuest('AWOLNurse').getSubQuests('AlumniGame').setDialogueBranch('AlumniGame');
        mod.quest.getQuest('AWOLNurse').getSubQuests('AlumniGame').setCondition(() => {
            return mod.quest.isComplete('AWOLNurse', 'FirstDay');
        });
        mod.quest.getQuest('AWOLNurse').setEnd('AlumniGame');
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Thomas', "Thanks for doing this. Here I told them that you needed to be paid up front so they all chipped in extra gold. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Natasha', "Whoa that is a ton more than last time. ", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Thomas', "Well I kind of told them your other job. They might be expecting a little more than what you did for the students. ", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Natasha', "Uh huh. ", "Surprise");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Thomas', "Ok then see you after the game!", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Natasha', "mumble mumble mumble couldn’t warn me to bring back up could you jerk mumble mumble", "Angry");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('', "The game goes just like you would expect for a bunch of middle aged ex-athletes. Natasha stays pretty busy fixing them up and by the end of the game she’s almost as tired as the players. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('', "Natasha walks into the locker room and is greeted by twelve large sweaty men. They cheer instantly. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Leon', "NURSE! NURSE! NURSE!", "Neutral");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Natasha', "Oh boy this is going to be fun but I don’t know if I have the energy. Time to rally! ", "Surprise");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Natasha', "First things first, you guys stink everyone in the shower! I see a lot of burly dad bods in this group, you had better be good with the soap!", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Natasha', "Ok as your nurse I want to see everyone getting nice and soapy. I’ll be coming around to check and make sure you are all being through. Take your time though, I need to make my rounds. ", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('', "Natasha wanders around the showers touching all of the guys. She grabs a butt here, licks a nipple there, massages a thigh, tickles some balls, soaps up a chest, and so on until she has been around the room a couple of times. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Natasha', "Now that I’m sure you are all nice and clean how about we get down to business. You all just exerted yourselves on the field. Time to let me examine you up close for any injuries that might be a bit longer lasting. ", "Happy");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('', "Big battle!", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('Natasha', "Whew who knew a bunch of old guys would be so much fun. Ok guys fun is over. Time for my shower. ", "Blush");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').talk('', "A couple of the guys carry her into the shower and soap her up before she heads back to the brothel. ", "");
        mod.dialogue.getDialogueTree('AWOLNurse').getBranch('AlumniGame').completeQuest('AWOLNurse', 'AlumniGame');
    };
}) ();