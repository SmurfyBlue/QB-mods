(() => {
    let mod = new Mod('CustomDebugUnlocker');
    mod.name = 'Custom Debug Unlocker';

    mod.boot = () => {
        //Unlock all girls and lvl them up to lvl 50
        for (girlName in gameData.girl) {
            gameData.girl[girlName].Unlocked = true;
            gameData.girl[girlName].EXP = 600000;
        }

        //Add a shit ton of gold
        gameData.gold = 500000;

        //Unlock all outfits. Should also unlock any mod-based outfits!
        for (clothing in gameData.clothes) {
            gameData.clothes[clothing].Unlocked = true;
        }

        //Set quests to true to instantly be able to access the shop
        gameData.newGame = false;
        gameData.quests.worldQuests.newGame = true;
        gameData.quests.worldQuests.firstVisitTown = true;
        gameData.quests.worldQuests.firstVisitCassie = true;
    }
})();